## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- fig.height=4, fig.width=4-----------------------------------------------
library(tiefightR)
raw       <- tiefightR::human
humantest <- tie_worth(xdata   = raw,
                     RF        = "img1",      # specify!
                     CF        = "img2",      # specify!
                     id        = "ID",        # specify!
                     RV        = "pref_img1", # specify!
                     showplot  = TRUE,
                     ymax      = 0.5,
                     intrans   = TRUE,        # change to false so save some calculation time
                     compstudy = "LargeValanceRange",
                     default   = "War",
                     ordn      = c("Cat", "Crow", "Doctor", "Frustrated", "Lake", "War", "Fire"))
humantest$worth
humantest$intrans


## ---- fig.height=4, fig.width=4-----------------------------------------------

human_test2 <- tie_worth(xdata = raw,
                     showplot  = FALSE,
                     compstudy = "LargeValanceRange",
                     default   = "War",
                     ordn      = c("Cat", "Crow", "Doctor", "Frustrated", "Lake", "War", "Fire"),
                     r1        = "Lake", # change this
                     r2        = "Cat")  # change this / to multiple combis
human_test2$worth

## ---- fig.height=4, fig.width=4-----------------------------------------------
# Import raw data (exmpl: mouse data)
raw_mouse  <- tiefightR::mouse

# binarize data (w/ constant seeding) - study/test_no 1
# NOTE: the binarized set is calculated with a constant seeding.
# You can change this w/ setseed = FALSE!
bin_mouse  <- tie_binarize(xdata      = raw_mouse,
                           RF         = "fluidType",
                           CF         = "combinationWith",
                           id         = "animalID",
                           RV         = "numOF_visits_with_Licks",
                           compiled_studies	 = 1,
                           setseed    = TRUE,  # requirement for a defined set 
                           prefLimit  = 50)

# calculate worth values w/ the binarized data
mouse1      <- tie_worth(xdata         = bin_mouse,
                        RF            = "img1",
                        CF            = "img2",
                        id            = "ID",
                        RV            = "pref_img1",
                        showplot      = TRUE,
                        ymin          = 0.10,
                        ymax          = 0.30,
                        intrans       = TRUE,
                        compstudy     = 1,
                        default       = "HCl",
                        ordn          = c("m10MSac", "m5MSac", "HCl", "NaCl", "water"),
                        r1            = NULL,
                        r2            = NULL)
mouse1$worth
mouse1$intrans

## -----------------------------------------------------------------------------
# Observe the position and mean intransitivity after R randomizations
raw     <- tiefightR::human
ord     <- c("Cat", "Crow", "Doctor", "Frustrated", "Lake", "War", "Fire")

mytest  <- tie_test(xdata     = raw,
                    R         = 2,       # adjust
                    intrans   = TRUE,
                    compstudy = "LagreValenceRange_SpringSchool",
                    default   = "War",
                    ord       = ord,
                    seed      = TRUE,
                    testme    = "Lake",  # Change 
                    against   = "Cat")   # Change items and watch intrans move
mytest

## -----------------------------------------------------------------------------
### Check the number of available CPU cores on your machine.
### Use k-2 later in the simulation or things could get ugly...
### Don't do this analysis on a single core machine.
library(tiefightR)
k <- tie_cores()
k

## ----echo=TRUE, fig.height=4, fig.width=5-------------------------------------
library(tiefightR)
# load some data for the simulation 
raw         <- tiefightR::human
ord         <- c("Cat", "Crow", "Doctor", "Frustrated", "Lake", "War", "Fire")

# Let's simulate 
set.seed(123)
testme      <- "Lake"
sim_humans  <- tie_sim(xdata     = raw,
                       R         = 2,           # No. of randomizations (here=3 to keep things easy)
                       cpus      = 6,           # enter the no- of CPUs
                       RF        = "img1",
                       CF        = "img2",
                       id        = "ID",
                       RV        = "pref_img1",
                       intrans   = TRUE,        
                       compstudy = "LagreValenceRange_SpringSchool",
                       default   = "War",
                       ord       = ord,
                       v1        = testme)

# Analyse the simulation result with the following function
tie_simrep(res  = sim_humans, v1   = testme)


