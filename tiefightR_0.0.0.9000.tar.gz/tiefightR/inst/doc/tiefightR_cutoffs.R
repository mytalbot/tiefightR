## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----echo=FALSE, fig.height=4, fig.width=6, warning = FALSE-------------------
library(tiefightR)
suppressWarnings(library(ggplot2))
suppressWarnings(library(ggpubr))

suppressWarnings(errorplot <- tie_cicheck(data       = tiefightR::mouse,
                         R          = 2, # max this FTW!
                         prefLimit  = 50,
                         ciLvl      = 0.95,
                         seed       = TRUE,
                         SV         = "side",
                         RF         = "fluidType",
                         CF         = "combinationWith",
                         id         = "animalID",
                         RV         = "numOF_visits_with_Licks",
                         ord        = c("m10MSac", "m5MSac", "HCl", "NaCl", "water"),
                         compstudy  = 1,
                         default    = "HCL",
                         showplot   = TRUE,
                         showstats  = FALSE))


## ----echo=FALSE, fig.height=4, fig.width=6, warning = FALSE-------------------
library(tiefightR)
library(ggplot2)
library(ggpubr)

errorplot <- tie_cicheck(data       = tiefightR::mouse,
                         R          = 10, # max this FTW!
                         prefLimit  = 50,
                         ciLvl      = 0.95,
                         seed       = TRUE,
                         SV         = "side",
                         RF         = "fluidType",
                         CF         = "combinationWith",
                         id         = "animalID",
                         RV         = "numOF_visits_with_Licks",
                         ord        = c("m10MSac", "m5MSac", "HCl", "NaCl", "water"),
                         compstudy  = 1,
                         default    = "HCL",
                         showplot   = TRUE,
                         showstats  = FALSE)

## ----echo=FALSE, fig.height=4, fig.width=6, warning = FALSE, set.seed(123)----
knitr::opts_chunk$set(cache = T)
library(tiefightR)
library(ggplot2)
library(ggpubr)


cutoff_50 <- tie_cutoff(data  = tiefightR::mouse, 
                        R          = 35,
                        ciLvl      = 0.95,
                        cpus       = 6,
                        SV         = "side",
                        RF         = "fluidType",
                        CF         = "combinationWith",
                        id         = "animalID",
                        RV         = "numOF_visits_with_Licks",
                        ord        = c("m10MSac", "m5MSac", "HCl", "NaCl", "water"),
                        prefLimit  = 50,
                        compstudy  = 1,
                        default    = "HCL")
 
cutoff_66 <- tie_cutoff(data       =tiefightR::mouse,  
                        R          = 35,
                        ciLvl      = 0.95,
                        cpus       = 6,
                        SV         = "side",
                        RF         = "fluidType",
                        CF         = "combinationWith",
                        id         = "animalID",
                        RV         = "numOF_visits_with_Licks",
                        ord        = c("m10MSac", "m5MSac", "HCl", "NaCl", "water"),
                        prefLimit  = 66,
                        compstudy  = 1,
                        default    = "HCL")

# combine data
d1 <- cutoff_50
d2 <- cutoff_66

# calulate the normalized CI range
d1$Cidelta <- NULL
d1$Cidelta <- (d1$upr-d1$lwr)/max(d1$upr-d1$lwr, na.rm=TRUE)
d2$Cidelta <- NULL
d2$Cidelta <- (d2$upr-d2$lwr)/max(d2$upr-d2$lwr, na.rm=TRUE)

# merge
d1$preflevel <- "50%"
d2$preflevel <- "66%"
df <- rbind(d1,d2)

# plot the distances with CIs
praw <- ggplot(df, aes(x=factor(R), y=dist, color=preflevel)) +
  geom_point() +
  geom_errorbar(aes(ymin=lwr, ymax=upr), width=.1 )+
  ylab("Mean Euclidean distance") +
  xlab("Randomizations") +
  labs(colour="Preference Limit") +
  scale_x_discrete(breaks = seq(1, 50, by = 4)) +
  theme_classic()
praw <- praw + scale_colour_manual(values=c("red","#663399"))
praw <- praw + theme(legend.position = c(0.85, 0.9))
praw

# where is the cutoff?
threshold <- 0.10
thr_50    <- which(d1$Cidelta <  threshold)[1]
thr_66    <- which(d2$Cidelta <  threshold)[1]

pci <- ggplot(df, aes(x=factor(R), y=Cidelta, color=preflevel)) +
  geom_point() +
  ylab("Standardized range of CIs") +
  xlab("Randomizations") +
  labs(colour="Preference Limit") +
  scale_x_discrete(breaks = seq(1, 50, by = 4)) +
  theme_classic()
pci <- pci + scale_colour_manual(values=c("red","#663399"))
pci <- pci + theme(legend.position = c(0.85, 0.9))
pci <- pci + geom_hline(yintercept =threshold   , linetype="dotted", color="black")
pci <- pci + geom_vline(xintercept =thr_50, linetype="dashed", color="red")
pci <- pci + geom_vline(xintercept =thr_66, linetype="dashed", color="#663399")
pci

print(paste("Cutoff threshold 50% prefLimit: ", thr_50, " randomizations are needed", sep=""))
print(paste("Cutoff threshold 66% prefLimit: ", thr_66, " randomizations are needed", sep=""))


