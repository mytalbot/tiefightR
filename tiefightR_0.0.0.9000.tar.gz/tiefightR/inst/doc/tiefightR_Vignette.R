## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
head(tiefightR::mouse)

## ----echo=TRUE----------------------------------------------------------------
 SV        = "side"                     # name of the side variable (default = "side_img1")
 RF        = "fluidType"                # name of the reference fluid variable (default = "img1")
 CF        = "combinationWith"          # name of the combination fluid variable (default = "img2")
 id        = "animalID"                 # subject IDs (default = "ID")
 RV        = "numOF_visits_with_Licks"  # name of the response variable (default = "pref_img1")

## ----echo=FALSE, fig.height=5, fig.width=5, out.width="60%"-------------------

library(tiefightR)
raw        <- tiefightR::mouse
set.seed(123)
bin_mouse  <- tie_binarize(xdata      = tiefightR::mouse,
                           SV         = "side",
                           RF         = "fluidType",
                           CF         = "combinationWith",
                           id         = "animalID",
                           RV         = "numOF_visits_with_Licks",
                           compiled_studies	 = 1,
                           setseed    = TRUE,
                           prefLimit  = 50)

mouse1      <- tie_worth(xdata         = bin_mouse,
                        SV            = "side_img1",
                        RF            = "img1",
                        CF            = "img2",
                        id            = "ID",
                        RV            = "pref_img1",
                        intrans       = FALSE,
                        compstudy     = 1,
                        default       = "HCl",
                        ordn          = c("m10MSac", "m5MSac", "HCl", "NaCl", "water"))

plot(mouse1$modelout, ylim=c(0.1,0.26), ylab="worth value")
arrows(1.25, 0.13, x1 = 1.25, y1 = 0.188, length = 0.15, angle = 90, code = 3, lwd=1.2)
text(1.39, 0.16, "Distance")

## ----echo=FALSE---------------------------------------------------------------
library(tiefightR)
raw        <- tiefightR::mouse
set.seed(123)
bin_mouse  <- tie_binarize(xdata      = tiefightR::mouse,
                           SV         = "side",
                           RF         = "fluidType",
                           CF         = "combinationWith",
                           id         = "animalID",
                           RV         = "numOF_visits_with_Licks",
                           compiled_studies	 = 1,
                           setseed    = TRUE,
                           prefLimit  = 50)

mytest  <- tie_test(xdata      = bin_mouse,
                    R          = 3,
                    intrans    = TRUE,
                    compstudy  = 1,
                    default    = "HCl",
                    ord        = c("m10MSac", "m5MSac", "HCl", "NaCl", "water"),
                    seed       = TRUE,
                    testme     = "NaCl",               
                    against    = "HCl") 

mytest

