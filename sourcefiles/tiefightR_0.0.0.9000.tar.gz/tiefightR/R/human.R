#' tiefightR - human data
#'
#' Two sets of seven pictures each were taken for preference ranking. The subjects for the first set were 32 (16 male, 16 female)
#' persons aged between 19 and 46 years (average: 25.5 years). The second set of pictures was ranked by 63 persons
#' (33 male, 29female, 1 other) with an average age of 29.1 years (ranging from 19-70). 73 of the probands were recruited at
#' the campus of the University of Göttingen, Germany and conducted the test in a controlled laboratory environment.
#' The other 22 persons conducted the internet-based test somewhere else. The first set of pictures was tested a second
#' time during the course of a graduate spring school by 16 participants (age range from 26 to 40 years, mean 31.1 years;
#' 12 female, 4 male).
#'
#' @docType data
#'
#' @usage data(human)
#'
#' @format A 2331 x 7 data frame with binary response data (pref_img1).
#'
#' @keywords datasets
#'
#' @examples
#' data(human)
#' head(human)
"human"
